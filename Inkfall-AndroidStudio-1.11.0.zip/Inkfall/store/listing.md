# Play Store mağaza metinleri

## Türkçe (tr-TR)

**Uygulama adı (en fazla 30 karakter)**
Inkfall: Meteor Defense

**Kısa açıklama (en fazla 80 karakter)**
Çiz, sektir, zincirle! Meteorları mürekkeple sektir, şehri meteordan kurtar.

**Tam açıklama**

Gökten meteorlar yağıyor ve şehrin tek savunması senin kalemin.

Parmağını sürükle, ışıldayan bir mürekkep çizgisi çiz. Meteorlar çizgine çarpıp seker. Sektirdiğin meteoru başka bir meteora çarptır, ikisi de patlasın. Kümelenmiş meteorlarda zincirleme patlamalar başlar, kombo büyür, puan katlanır.

★ TEK PARMAKLA OYNANIR, USTALIK İSTER
Çizerken zaman yavaşlar ve nişan almak kolaylaşır. Ama mürekkebin sınırlı: kısa ve doğru açılı çizgiler kazandırır.

★ HER OYUN FARKLI
Her dalga sonunda 3 güçten birini seç: Mıknatıs Uç, Koruyucu Uydu, Zincir Şimşek, Kara Delik, Anka Kuşu ve dahası. 27 güç, hepsi eşit: istediğini seç.

★ ŞEKİL ÇİZ, YETENEK AT
Ekrana daire çiz: Yıldız Patlaması. Üçgen: Zaman Kırılması. Kare: Aegis Kalkanı. Zikzak: Yıldız Yağmuru. Sonsuzluk: Sonsuz Yansıma. Sarmal: Kara Girdap. Yıldız: Yıldız Işınları. Orion takımyıldızındaki her yıldız bir yetenek: aç, üç seviyeye kadar geliştir, en sevdiğin üçünü parşömene koy.

★ BEŞ ÇETİN BOSS
Kaya Titanı, Kuyruklu Kraliçe, Buz Kalesi, Tekillik ve İkiz Yıldızlar gökyüzünde dolaşır. Her birinin kendi taktiği var.

★ YENİ METEORLAR
Çapraz dalan kuyruklu yıldızlar, çizgini donduran buz kristalleri, saydamlaşan hayaletler, dev zincir başlatan nova çekirdekleri, yana ışınlanan meteorlar, çizgini yakan alev meteorları, üçe bölünen prizmalar, şehri onaran şifa kristalleri ve yılan gibi süzülen kıvılcım sürüleri.

★ MÜREKKEP ATEŞİ
Komboyu büyüt, Mürekkep Ateşi'ni yak: mürekkep bedava, çizgiler gökkuşağı, puan katlanır.

★ DOKUZ UZAY DÜNYASI
Her bölüm sonunda sahne tamburu döner, arkasından yeni bir dünya çıkar: Gece, Alacakaranlık, Kuzey Işıkları, Kızıl Kıyamet, Kozmos, Orion Bulutsusu, Satürn Halkaları, Olay Ufku ve Süpernova. Her dünyanın kendi gökyüzü, müziği ve sürprizi var.

★ REKABET
Çıraklıktan Efsane'ye uzanan hat sanatı rütbeleri. Her gün herkesin aynı meteorlarla oynadığı günlük meydan okuma, 7 günlük hediye takvimi, günlük seri bonusu, görevler ve rekor tablosu.

★ ŞEHRİN GECESİ
Ebru desenli bir gökyüzü, Boğaz Köprüsü'nün ışıkları, apartmanlar ve cumbalı evler. Hicaz makamında üretken müzik ve her sekmede yükselen melodik sesler.

★ ŞEHRİNİ GİYDİR
İstanbul'un cumbalı evleriyle başla; şehrini Tokyo'nun neon sokaklarına, Paris'in mansart çatılarına, Los Angeles'ın palmiyelerine, New York'un gökdelenlerine, Dubai'nin cam kulelerine ya da Ay Kolonisi'nin cam kubbelerine dönüştür.

★ ADİL VE ÜCRETSİZ
Oyun tamamen ücretsiz. İstersen video izleyip kaldığın yerden devam et ya da bedava altın kazan. Birkaç oyunda bir kısa bir reklam çıkar; Reklamsız paketle tamamen kalkar.

## English (en-US)

**App name**
Inkfall: Meteor Defense

**Short description (max 80 characters)**
Draw, deflect, chain! Bounce meteors with ink and save the city.

**Full description**

Meteors are raining down and the city's only defense is your pen.

Drag your finger to draw a glowing ink line. Meteors bounce off it. Deflect one into another and both explode. Clustered meteors set off chain reactions, your combo grows and your score multiplies.

★ ONE FINGER, REAL SKILL
Time slows while you draw so you can aim. But ink is limited: short, well-angled lines win.

★ EVERY RUN IS DIFFERENT
After each wave pick one of three powers: Magnet Nib, Guardian Satellite, Chain Lightning, Black Hole, Phoenix and more. 27 powers, all equal: pick the one you like.

★ DRAW A SHAPE, CAST A SKILL
Draw a circle for Starburst, a triangle for Time Fracture, a square for Aegis Shield, a zigzag for Starfall, an infinity sign for Infinite Echo, a spiral for Dark Vortex and a star for Star Beams. Every star of the Orion constellation is a skill: unlock it, upgrade it and pin your favourite three to your scrolls.

★ FIVE TOUGH BOSSES
Rock Titan, Comet Queen, Frost Citadel, Singularity and Twin Stars roam the sky, each with its own tactics.

★ NEW METEORS
Diving comets, ice crystals that freeze your lines, fading phantoms, nova cores that set off giant chains, blink meteors that teleport, flares that burn your lines, prisms that split in three, mending crystals that repair the city and weaving wisp swarms.

★ INK FEVER
Build your combo to ignite Ink Fever: free ink, rainbow lines and boosted score.

★ NINE SPACE WORLDS
At the end of each chapter the stage turns and a new world appears behind it: Night, Dusk, Northern Lights, Crimson Doom, Cosmos, Orion Nebula, Saturn's Rings, Event Horizon and Supernova. Each has its own sky, music and twist.

★ COMPETITION
Calligraphy ranks from Apprentice to Legend. A daily challenge where everyone plays the same meteors, a 7-day gift calendar, daily streak bonus, missions and records.

★ THE CITY AT NIGHT
A marbled ebru sky, the lights of the Bosphorus Bridge, apartment blocks and wooden bay-window houses. Generative music in the Hicaz maqam, with melodic notes that climb with every bounce.

★ DRESS YOUR CITY
Start by guarding Istanbul's bay-window houses, then turn your city into the neon streets of Tokyo, the mansard roofs of Paris, the palm trees of Los Angeles, the skyscrapers of New York, the glass towers of Dubai or the glass domes of a Moon Colony.

★ FAIR AND FREE
The game is completely free. Watch a video only when you want to continue your run or earn free gold. A short ad appears every few games; the No Ads pack removes ads entirely.

## Kategori ve etiketler

- Kategori: Oyun → Arcade
- Etiketler: Arcade, Tek oyunculu, Stilize, Uzay
- Reklam içerir: Evet (isteğe bağlı ödüllü videolar ve her 5 oyunda bir geçiş reklamı; Reklamsız paketle kalkar)
- Uygulama içi satın alma: Evet
- İletişim e-postası: (Play Console'da kendi adresini gir)

## Sürüm notları (1.11.0)

**TR:** Altı yeni şehir kostümü: Tokyo, Paris, Los Angeles, New York, Dubai ve Ay Kolonisi. Kalemler menüsü Koleksiyon oldu. Ölünce video izleyip devam etme, kartları videoyla yenileme ve düşük donanımlı cihazlarda daha akıcı açılış.

**EN:** Six new city costumes: Tokyo, Paris, Los Angeles, New York, Dubai and Moon Colony. The Pens menu is now the Collection. Watch a video to continue after a fall, reroll power cards with a video, and smoother first launch on low-end devices.

## Sürüm notları (1.9.0)

**TR:** Geçişler, kart seçimi, dalga sonu ve ekran yazılarındaki takılmalar giderildi: ağır hazırlıklar arka planda küçük adımlarla yapılıyor. Güç kartlarında nadirlik kalktı, hepsi eşit. Dünyalar ekranı eşit boyutlu, yana kaydırmalı yeni bir galeri oldu.

**EN:** Removed stutters during transitions, card picks, wave ends and on-screen texts: heavy preparation now runs in the background in small steps. Power cards no longer have rarities; all cards are equal. The Worlds screen is a new swipeable gallery of equal-size cards.

## Sürüm notları (1.8.1)

**TR:** Çizilen şekiller artık çok daha doğru tanınıyor (yumurta biçimli daireler, yuvarlak köşeli kareler, hızlı çizimler); yetenek beklerken ya da kilitliyken ekranda açıkça yazıyor. Kalemler, Atölye, Görevler, Rekorlar, Mağaza ve Ayarlar menüleri ana ekranın uzay sahnesiyle bütünleşen yeni, animasyonlu tasarımda: yörüngeli gezegenler, kendini çizen mürekkep çizgileri, parlayan ilerleme çubukları.

**EN:** Drawn shapes are recognised far more reliably (egg-shaped circles, rounded squares, quick strokes), and the game clearly tells you when a skill is recharging or locked. Pens, Workshop, Missions, Records, Shop and Settings get a new animated design that blends into the space scene: orbiting planets, self-drawing ink strokes and glowing progress bars.

## Sürüm notları (1.7.0)

**TR:** Üç yeni yetenek (Sonsuz Yansıma, Kara Girdap, Yıldız Işınları) ve Orion takımyıldızı şeklinde yeni yetenek ekranı, 3 yetenek parşömeni, yeniden tasarlanan Dünyalar ekranı, ileri dünyalardan kart seçtirmeden hızlı başlangıç, üst üste binmeyen oyun içi yazılar, HD görüntü ve akıcılık iyileştirmeleri.

**EN:** Three new skills (Infinite Echo, Dark Vortex, Star Beams) and a new Orion constellation skill screen, 3 skill scrolls, a redesigned Worlds screen, instant starts from later worlds, non-overlapping in-game texts, HD visuals and smoothness improvements.

## Sürüm notları (1.5.0)

**TR:** Şekil çizerek yetenek atma ve Yetenek Ağacı, beş yeni meteor türü, Mürekkep Ateşi, seçtiğin dünyadan başlama, yeni açılış ekranı ve yumuşak müzik, performans iyileştirmeleri.

**EN:** Cast skills by drawing shapes plus a Skill Tree, five new meteor types, Ink Fever, start from any unlocked world, a new splash screen and softer music, performance improvements.
