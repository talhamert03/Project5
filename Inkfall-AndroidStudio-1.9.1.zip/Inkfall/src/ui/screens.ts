import type { SaveData } from '../core/storage';
import type { RunResult } from '../game/world';
import { PENS, type Pen } from '../game/pens';
import { UPGRADE_BY_ID } from '../game/upgrades';
import { getLang, t } from '../i18n';
import { ATMOSPHERES, atmosphereIndexForWave, firstWaveOf } from '../render/atmospheres';
import {
  type DailyInfo,
  GIFT_REWARDS,
  type GiftState,
  RANKS,
  type RankProgress,
  SKILLS,
  SKILL_BY_ID,
  SKILL_MAX_LV,
  SCROLL_SLOTS,
  type Settlement,
  WORKSHOP,
  rankProgress,
  skillUpCost,
} from '../meta/progression';
import { FREE_COINS, FREE_COINS_PER_DAY, SHOP, priceOf } from '../monetize';
import { fmt, fmtDuration, fmtTime, roman } from './format';
import { shapeGuide } from '../game/gesture';
import { shapeIcon } from './hud';
import { icon } from './icons';

export function rankLabel(idx: number): string {
  const r = RANKS[idx];
  return `${t('rank.' + r.key)}${r.tier ? ' ' + roman(r.tier) : ''}`;
}

function seal(idx: number, size = 48): string {
  const r = RANKS[idx];
  const letter = t('rank.' + r.key).charAt(0).toLocaleUpperCase(getLang() === 'tr' ? 'tr-TR' : 'en-US');
  return `<div class="seal" style="--rc:${r.color};--s:${size}px"><b>${letter}</b>${r.tier ? `<i>${roman(r.tier)}</i>` : ''}</div>`;
}

export function rankCard(p: RankProgress, best: number, extraClass = '', rankUp = false): string {
  const next = p.next ? t('menu.toNext', { rank: rankLabel(p.idx + 1), n: fmt(p.need) }) : t('menu.maxRank');
  return `
    <div class="rank-card ${extraClass}" style="--rc:${p.rank.color}">
      ${seal(p.idx)}
      <div class="rank-info">
        ${rankUp ? `<div class="rank-up">${icon('star')}${t('over.rankUp')}</div>` : ''}
        <div class="rank-name">${rankLabel(p.idx)}</div>
        <div class="bar"><i style="--w:${(p.frac * 100).toFixed(1)}%"></i></div>
        <div class="rank-next">${next}</div>
      </div>
      <div class="best-box"><small>${t('menu.best')}</small><b>${fmt(best)}</b></div>
    </div>`;
}

const LOGO_STROKE = `<svg class="logo-stroke" viewBox="0 0 300 22" preserveAspectRatio="none"><path d="M6 14 C 60 2, 110 20, 160 10 S 250 4, 294 12"/></svg>`;

/**
 * Açılış: bir meteor düşer, kendiliğinden çizilen mürekkep çizgisine çarpıp mürekkep rengine
 * dönerek geri seker, logo belirir, yükleme çubuğu dolar. Yalnızca opaklık ve dönüşüm
 * animasyonları (GPU'da birleştirilir); bitince ana menüye yumuşakça açılır.
 */
export function bootHTML(): string {
  const sparks = [-160, -130, -100, -70, -40, -15, 200, 235]
    .map((a, i) => `<span style="transform:rotate(${a}deg)"><i style="animation-delay:${1.12 + i * 0.012}s"></i></span>`)
    .join('');
  return `
      <div class="sp-sky"></div>
      <div class="sp-glow"></div>
      <div class="sp-flash"></div>
      <div class="sp-stage">
        <svg class="sp-ink" viewBox="0 0 320 60" preserveAspectRatio="none"><path d="M22 44 C 90 26, 180 22, 298 34"/></svg>
        <i class="sp-ring"></i>
        <div class="sp-sparks">${sparks}</div>
        <i class="sp-met"><b class="hot"></b><b class="cool"></b></i>
      </div>
      <h1 class="logo sp-logo"><span>${t('app.title1')}</span><span>${t('app.title2')}</span></h1>
      <p class="tagline sp-tag">${t('app.tagline')}</p>
      <div class="sp-load"><i></i></div>
      ${skylineSVG()}`;
}

/** Açılış ekranının altındaki şehir silüeti (sabit tohumla, her açılışta aynı) */
function skylineSVG(): string {
  let seed = 7;
  const rnd = (): number => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  let x = 0;
  let body = '';
  let lights = '';
  while (x < 400) {
    const w = 18 + Math.floor(rnd() * 26);
    const h = 26 + Math.floor(rnd() * 64);
    body += `<rect x="${x}" y="${120 - h}" width="${w - 2}" height="${h}"/>`;
    for (let wy = 120 - h + 6; wy < 114; wy += 9) {
      for (let wx = x + 4; wx < x + w - 6; wx += 7) if (rnd() < 0.22) lights += `<rect x="${wx}" y="${wy}" width="3" height="4"/>`;
    }
    x += w;
  }
  return `<svg class="sp-city" viewBox="0 0 400 120" preserveAspectRatio="xMidYMax slice"><g class="b">${body}</g><g class="l">${lights}</g></svg>`;
}

export interface MenuData {
  save: SaveData;
  daily: DailyInfo;
  gift: GiftState;
  worldName: string;
  worldIndex: number;
}

/** Mobil oyun ana ekranı: üst profil çubuğu, yan hızlı butonlar, büyük OYNA */
export function menuHTML(d: MenuData): string {
  const s = d.save;
  const p = rankProgress(s.best);
  const unlocked = Math.min(ATMOSPHERES.length, s.maxAtm + 1);
  const meta: string[] = [];
  if (s.streak.count > 0) meta.push(`<span class="meta-chip streak">${icon('flame')}${t('menu.streakDays', { n: s.streak.count })}</span>`);
  const atm = ATMOSPHERES[d.worldIndex];
  const owned = SKILLS.filter((k) => s.skills.includes(k.id));
  const lockedN = SKILLS.length - owned.length;
  // menü şeridi: parşömendeki (oyunda rehber olan) yetenekler
  const strip = s.scrolls
    .filter((id) => s.skills.includes(id))
    .slice(0, SCROLL_SLOTS)
    .map((id) => SKILL_BY_ID.get(id)!)
    .map((k) => `<span class="ss" style="--sc:${k.color}">${shapeIcon(k.shape)}<em>${t('shape.' + k.shape)}</em></span>`)
    .join('');
  return `
    <section class="screen home" id="menu">
      <header class="topbar enter" style="--d:0">
        <button class="profile" data-a="panel" data-p="records" style="--rc:${p.rank.color}">
          ${seal(p.idx, 42)}
          <span class="profile-info">
            <b>${rankLabel(p.idx)}</b>
            <span class="xp"><i style="--w:${(p.frac * 100).toFixed(1)}%"></i></span>
          </span>
        </button>
        <div class="top-right">
          <button class="currency" data-a="shop">${icon('coin')}<b class="coin-count" id="m-coins">${fmt(s.coins)}</b><span class="plus">+</span></button>
          <button class="icon-btn sm" data-a="panel" data-p="settings" aria-label="${t('menu.settings')}">${icon('gear')}</button>
        </div>
      </header>

      <div class="brand home-brand enter" style="--d:1;--ac:${atm.accent}">
        <i class="brand-rays"></i>
        <h1 class="logo"><span>${t('app.title1')}</span><span>${t('app.title2')}</span>${LOGO_STROKE}</h1>
      </div>

      <div class="home-mid">
        <div class="side left">
          <button class="fab gift ${d.gift.ready ? 'ready' : ''}" data-a="gift" style="--ac:var(--gold)">
            <span class="fab-ic">${icon('gift')}${d.gift.ready ? '<i class="dot">!</i>' : ''}</span>
            <span class="fab-label">${t('menu.gift')}</span>
          </button>
          <button class="fab" data-a="panel" data-p="daily" style="--ac:var(--ember)">
            <span class="fab-ic">${icon('calendar')}</span>
            <span class="fab-label">${t('menu.daily')}</span>
            <small class="fab-sub">${t('mod.' + d.daily.mod.id)}</small>
          </button>
          <button class="fab shop-fab" data-a="shop" style="--ac:var(--gold)">
            <span class="fab-ic">${icon('bag')}${!s.starter ? '<i class="dot">%</i>' : ''}</span>
            <span class="fab-label">${t('menu.shop')}</span>
          </button>
        </div>
        <div class="side right">
          <button class="fab" data-a="panel" data-p="worlds" style="--ac:${ATMOSPHERES[Math.min(unlocked, ATMOSPHERES.length) - 1].accent}">
            <span class="fab-ic">${icon('planet')}</span>
            <span class="fab-label">${t('menu.worlds')}</span>
            <small class="fab-sub">${unlocked}/${ATMOSPHERES.length}</small>
          </button>
          <button class="fab" data-a="panel" data-p="skills" style="--ac:#B57BFF">
            <span class="fab-ic">${icon('stars')}</span>
            <span class="fab-label">${t('menu.skills')}</span>
            <small class="fab-sub">${owned.length}/${SKILLS.length}</small>
          </button>
        </div>
      </div>

      <div class="home-play enter" style="--d:2">
        ${meta.length ? `<div class="play-meta">${meta.join('')}</div>` : ''}
        <button class="stage-card" data-a="panel" data-p="worlds" style="--ac:${atm.accent}">
          <span class="stage-ic">${icon('planet')}</span>
          <span class="stage-info">
            <small>${t('banner.chapter', { n: d.worldIndex + 1 })} · ${unlocked}/${ATMOSPHERES.length}</small>
            <b>${d.worldName}</b>
            <span class="stage-bar"><i style="--w:${((unlocked / ATMOSPHERES.length) * 100).toFixed(1)}%"></i></span>
          </span>
          <span class="stage-best">${s.bestWave > 0 ? `<small>${t('hud.wave')}</small><b>${s.bestWave}</b>` : ''}</span>
          <span class="stage-go">${icon('arrow')}</span>
        </button>
        <button class="skill-strip" data-a="panel" data-p="skills">
          <span class="ss-title">${t('skills.draw')}</span>
          ${strip}
          ${owned.length > SCROLL_SLOTS || lockedN > 0 ? `<span class="ss more">${icon('stars')}<em>${owned.length}/${SKILLS.length}</em></span>` : ''}
        </button>
        <div class="play-wrap">
          <span class="ring"></span>
          <button class="btn-play big" data-a="play">${icon('play')}<span class="play-text">${t('menu.play')}</span></button>
        </div>
      </div>
    </section>`;
}

export type TabName = 'pens' | 'workshop' | 'home' | 'missions' | 'records';

/** Alt sekme çubuğu (menüde her zaman görünür) */
export function tabbarHTML(active: TabName, missionsBadge: number, canBuy: boolean): string {
  const tab = (id: TabName, ic: string, label: string, badge = ''): string =>
    `<button class="tab ${active === id ? 'active' : ''} ${id === 'home' ? 'home-tab' : ''}" data-a="tab" data-p="${id}">
      <span class="tab-ic">${icon(ic)}${badge}</span><span class="tab-label">${label}</span>
    </button>`;
  return `
    <nav class="tabbar" aria-label="menu">
      ${tab('pens', 'pen', t('menu.pens'))}
      ${tab('workshop', 'hammer', t('menu.workshop'), canBuy ? '<i class="badge dot"></i>' : '')}
      ${tab('home', 'home', t('menu.home'))}
      ${tab('missions', 'target', t('menu.missions'), missionsBadge > 0 ? `<i class="badge">${missionsBadge}</i>` : '')}
      ${tab('records', 'trophy', t('menu.records'))}
    </nav>`;
}

/** Dünyalar galerisi: açılan atmosferler, menü arka planı seçimi */
/**
 * Dünya seçimi: yana kaydırmalı galeri. Bütün kartlar aynı boyda; dünyanın resmi kartı tamamen
 * kaplar, ortadaki kart öne çıkar. Altta dokunulabilir gezegen şeridi (açık / seçili / kilitli).
 */
export function worldsHTML(save: SaveData, thumbs: string[], current: number): string {
  const open = Math.min(save.maxAtm + 1, ATMOSPHERES.length);
  const cards = ATMOSPHERES.map((a, i) => {
    const unlocked = i <= save.maxAtm;
    const selected = unlocked && i === current;
    const first = firstWaveOf(i);
    const range = i === ATMOSPHERES.length - 1 ? t('worlds.wavesEnd', { a: first }) : t('worlds.waves', { a: first, b: first + 4 });
    const art = thumbs[i] ? ` ready" style="background-image:url(${thumbs[i]})` : '';
    const go = unlocked
      ? `<button class="wc-go" data-a="worldGo" data-i="${i}">${icon('play')}<span>${selected ? t('worlds.continue') : t('worlds.go')}</span></button>`
      : `<button class="wc-go locked" data-a="worldGo" data-i="${i}">${icon('lock')}<span>${t('worlds.lockedAt', { n: first })}</span></button>`;
    return `
      <article class="wc ${unlocked ? '' : 'locked'} ${selected ? 'selected' : ''}" style="--ac:${a.accent}">
        <div class="wc-art${art}" data-thumb="${i}"></div>
        <i class="wc-shade"></i>
        <span class="wc-chap">${t('banner.chapter', { n: i + 1 })}</span>
        ${selected ? `<span class="wc-sel">${icon('check')}${t('worlds.selected')}</span>` : ''}
        ${unlocked ? '' : `<span class="wc-lock">${icon('lock')}</span>`}
        <div class="wc-body">
          <h3>${t('atm.' + a.id)}</h3>
          <span class="wc-range">${range}</span>
          <p>${t('atm.' + a.id + '.d')}</p>
          ${go}
        </div>
      </article>`;
  }).join('');
  const dots = ATMOSPHERES.map((a, i) => {
    const unlocked = i <= save.maxAtm;
    return `<button class="wdot ${unlocked ? '' : 'locked'} ${i === current ? 'cur' : ''}" data-a="worldDot" data-i="${i}" style="--ac:${a.accent}" aria-label="${t('atm.' + a.id)}"><i></i></button>`;
  }).join('');
  return panel(
    'worlds',
    t('worlds.title'),
    `<div class="wsel">
      <div class="wsel-head">
        <h3>${t('worlds.ask')}</h3>
        <p>${t('worlds.sub')}</p>
      </div>
      <div class="wcar">${cards}</div>
      <div class="wtrack"><span class="wtrack-line"></span>${dots}</div>
      <p class="wtrack-cap">${t('worlds.open', { a: open, b: ATMOSPHERES.length })}</p>
    </div>`,
    save.coins,
  );
}

/** Günlük hediye penceresi (7 günlük takvim) */
export function giftHTML(g: GiftState, noAds = false): string {
  const days = GIFT_REWARDS.map((r, i) => {
    const done = g.ready ? i < g.day : i <= g.day;
    const today = g.ready && i === g.day;
    return `
      <div class="gday ${done ? 'done' : ''} ${today ? 'today' : ''} ${i === 6 ? 'big' : ''}" style="--d:${i}">
        <small>${t('gift.day', { n: i + 1 })}</small>
        <span class="g-ic">${done ? icon('check') : icon(i === 6 ? 'gift' : 'coin')}</span>
        <b>${fmt(r)}</b>
      </div>`;
  }).join('');
  return `
    <section class="screen modal" id="gift-modal">
      <div class="modal-card gift-card">
        <button class="icon-btn sm modal-x" data-a="closeModal" aria-label="${t('common.close')}">${icon('close')}</button>
        <div class="gift-hero ${g.ready ? 'ready' : ''}">${icon('gift')}</div>
        <h2>${t('gift.title')}</h2>
        <p>${t('gift.desc')}</p>
        <div class="gift-grid">${days}</div>
        ${
          g.ready
            ? `<button class="btn-play gold btn-video" data-a="claimGift2x">${icon(noAds ? 'x2' : 'video')}${t('gift.claim2x', { n: fmt(GIFT_REWARDS[g.day] * 2) })}</button>
               <button class="btn-ghost wide" data-a="claimGift">${icon('coin')}${t('gift.claim', { n: fmt(GIFT_REWARDS[g.day]) })}</button>`
            : `<button class="btn-ghost wide" data-a="closeModal">${t('gift.tomorrow')}</button>`
        }
      </div>
    </section>`;
}

export interface ReviveOffer {
  /** video ile devam hakkı var mı (turda bir kez) */
  video: boolean;
  noAds: boolean;
  cost: number;
  bank: number;
  seconds: number;
}

/** Şehir düşerken: video izleyerek (ya da altınla) devam et */
export function reviveHTML(o: ReviveOffer): string {
  const canCoins = o.cost > 0 && o.bank >= o.cost;
  return `
    <section class="screen modal revive" id="revive-modal">
      <div class="modal-card revive-card">
        <div class="revive-timer" style="--dur:${o.seconds}s">
          <svg viewBox="0 0 64 64"><circle class="bg" cx="32" cy="32" r="28"/><circle class="fg" cx="32" cy="32" r="28"/></svg>
          <span>${icon('house')}</span>
        </div>
        <h2>${t('revive.title')}</h2>
        <p>${t('revive.desc')}</p>
        ${
          o.video
            ? `<button class="btn-play gold btn-video" data-a="reviveVideo">${icon(o.noAds ? 'play' : 'video')}<span>${o.noAds ? t('revive.free') : t('revive.video')}</span></button>`
            : ''
        }
        ${
          canCoins
            ? `<button class="${o.video ? 'btn-ghost wide coin-alt' : 'btn-play gold'}" data-a="revive">${icon('coin')}${fmt(o.cost)} · ${t('revive.go')}</button>`
            : ''
        }
        <button class="btn-ghost wide" data-a="giveup">${t('revive.no')}</button>
        ${o.cost > 0 ? `<small class="bank">${t('revive.bank', { n: fmt(o.bank) })}</small>` : ''}
      </div>
    </section>`;
}

/** Web demo reklamı (gerçek uygulamada burada AdMob videosu oynar) */
/** Web/önizleme reklam temsili. inter: araya giren (zorunlu) reklam, değilse ödüllü video */
export function adHTML(seconds: number, inter = false): string {
  return `
    <section class="screen modal ad-demo" id="ad-demo">
      <div class="ad-card">
        <div class="ad-top"><span class="ad-tag">${t('ad.tag')}</span><span class="ad-count" id="ad-count">${seconds}</span></div>
        <div class="ad-stage">
          <div class="ad-logo">${icon(inter ? 'noads' : 'video')}</div>
          <b>${t(inter ? 'ad.titleInter' : 'ad.title')}</b>
          <p>${t(inter ? 'ad.descInter' : 'ad.desc')}</p>
        </div>
        <div class="ad-bar"><i style="--dur:${seconds}s"></i></div>
        <button class="btn-ghost wide" data-a="adClose" id="ad-close" hidden>${t(inter ? 'ad.continue' : 'ad.close')}</button>
      </div>
    </section>`;
}

/** Mağaza: altın paketleri, başlangıç paketi, reklamsız ve günlük ücretsiz altın */
export function shopHTML(save: SaveData, native: boolean): string {
  const lang = getLang();
  const today = new Date().toISOString().slice(0, 10);
  const used = save.adCoins.date === today ? save.adCoins.n : 0;
  const left = Math.max(0, FREE_COINS_PER_DAY - used);
  const free = `
    <div class="shop-free" style="--d:0">
      <div class="ic">${icon('video')}</div>
      <div><h4>${t('shop.free', { n: FREE_COINS })}</h4><p>${t('shop.freeLeft', { n: left, max: FREE_COINS_PER_DAY })}</p></div>
      <button class="buy ${left > 0 ? '' : 'disabled'}" data-a="freeCoins">${icon(save.noAds ? 'coin' : 'video')}${t('shop.watch')}</button>
    </div>`;
  const packs = SHOP.filter((i) => i.kind === 'coins')
    .map(
      (i, k) => `
      <button class="pack ${i.tag ?? ''}" data-a="buy" data-id="${i.id}" style="--d:${k + 2}">
        ${i.tag ? `<span class="pack-tag">${t('shop.' + i.tag)}</span>` : ''}
        <span class="pack-coins">${'<i></i>'.repeat(Math.min(4, k + 1))}${icon('coin')}</span>
        <b>${fmt(i.coins)}</b>
        ${i.bonus ? `<small class="pack-bonus">+%${i.bonus}</small>` : '<small class="pack-bonus"></small>'}
        <span class="pack-price">${priceOf(i.id, lang)}</span>
      </button>`,
    )
    .join('');
  const starter = SHOP.find((i) => i.kind === 'starter')!;
  const noads = SHOP.find((i) => i.kind === 'noads')!;
  const starterCard = save.starter
    ? ''
    : `
    <button class="offer starter" data-a="buy" data-id="${starter.id}" style="--d:1">
      <span class="offer-badge">${t('shop.once')}</span>
      <div class="offer-art">${icon('gem')}</div>
      <div class="offer-body">
        <h4>${t('shop.starter')}</h4>
        <p>${t('shop.starterDesc', { n: fmt(starter.coins) })}</p>
      </div>
      <span class="pack-price">${priceOf(starter.id, lang)}</span>
    </button>`;
  const noadsCard = save.noAds
    ? `<div class="offer noads owned" style="--d:7"><div class="offer-art">${icon('noads')}</div><div class="offer-body"><h4>${t('shop.noads')}</h4><p>${t('shop.noadsOwned')}</p></div><span class="buy done">${icon('check')}</span></div>`
    : `
    <button class="offer noads" data-a="buy" data-id="${noads.id}" style="--d:7">
      <div class="offer-art">${icon('noads')}</div>
      <div class="offer-body"><h4>${t('shop.noads')}</h4><p>${t('shop.noadsDesc')}</p></div>
      <span class="pack-price">${priceOf(noads.id, lang)}</span>
    </button>`;
  const body = `
    ${starterCard}
    <h3 class="shop-h">${t('shop.coins')}</h3>
    <div class="packs">${packs}</div>
    ${noadsCard}
    ${free}
    <div class="shop-foot">
      ${native ? `<button class="btn-ghost" data-a="restore">${t('shop.restore')}</button>` : `<p class="note">${t('shop.demo')}</p>`}
    </div>`;
  return panel('shop', t('shop.title'), body, save.coins);
}

/** Yetenekler: bir tanesi takılır, dolunca oyunda tek dokunuşla tetiklenir */
/** Orion takımyıldızı çizgileri (yıldız adları; Meissa baş, M42 kılıç: süs) */
const ORION_LINES: Array<[string, string]> = [
  ['Betelgeuse', 'Meissa'],
  ['Meissa', 'Bellatrix'],
  ['Betelgeuse', 'Alnitak'],
  ['Bellatrix', 'Mintaka'],
  ['Alnitak', 'Alnilam'],
  ['Alnilam', 'Mintaka'],
  ['Alnitak', 'Saiph'],
  ['Mintaka', 'Rigel'],
];
const ORION_EXTRA: Record<string, [number, number]> = { Meissa: [50, 7] };
/** takımyıldız görünüm kutusunun yüksekliği (genişlik 100) */
const ORION_H = 124;

/** Şekil kılavuzundan küçük bir SVG yolu (0..100) */
function shapePath(shape: string): string {
  const pts = shapeGuide(shape as Parameters<typeof shapeGuide>[0]);
  return pts.map(([x, y], i) => `${i ? 'L' : 'M'}${(x * 100).toFixed(1)} ${(y * 100).toFixed(1)}`).join(' ');
}

/**
 * Yetenek Takımyıldızı (Orion): her yıldız bir yetenek. Yıldıza dokununca ayrıntı kartı: şeklin
 * kendini çizen canlandırması, açıklama, seviye, aç/geliştir ve parşömen düğmesi.
 */
export function skillsHTML(save: SaveData, selected = 'nova'): string {
  const dec = (v: number): string => (getLang() === 'tr' ? String(v).replace('.', ',') : String(v));
  const lvOf = (id: string): number => (save.skills.includes(id) ? Math.max(1, Math.min(SKILL_MAX_LV, save.skillLv[id] ?? 1)) : 0);
  const posOf = (name: string): [number, number] | undefined => SKILLS.find((k) => k.star === name)?.pos ?? ORION_EXTRA[name];
  const scrolls = save.scrolls.filter((id) => save.skills.includes(id)).slice(0, SCROLL_SLOTS);
  const sel = SKILLS.find((k) => k.id === selected) ?? SKILLS[0];

  // gökyüzü: sabit toz yıldızlar + takımyıldız çizgileri
  let dust = '';
  let seed = 11;
  const rnd = (): number => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 46; i++) {
    dust += `<circle cx="${(rnd() * 100).toFixed(1)}" cy="${(rnd() * ORION_H).toFixed(1)}" r="${(0.15 + rnd() * 0.35).toFixed(2)}" opacity="${(0.25 + rnd() * 0.6).toFixed(2)}"/>`;
  }
  const scaleY = ORION_H / 130;
  const lines = ORION_LINES.map(([a, b]) => {
    const pa = posOf(a);
    const pb = posOf(b);
    if (!pa || !pb) return '';
    const on = [a, b].every((n) => !SKILLS.find((k) => k.star === n) || save.skills.includes(SKILLS.find((k) => k.star === n)!.id));
    return `<line class="${on ? 'on' : ''}" x1="${pa[0]}" y1="${(pa[1] * scaleY).toFixed(1)}" x2="${pb[0]}" y2="${(pb[1] * scaleY).toFixed(1)}"/>`;
  }).join('');
  const meissa = ORION_EXTRA.Meissa;
  const sky = `
    <svg class="orion-sky" viewBox="0 0 100 ${ORION_H}" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
      <g class="dust">${dust}</g>
      <ellipse class="m42" cx="51" cy="${(88 * scaleY).toFixed(1)}" rx="4" ry="6"/>
      <g class="clines">${lines}</g>
      <circle class="meissa" cx="${meissa[0]}" cy="${(meissa[1] * scaleY).toFixed(1)}" r="0.9"/>
    </svg>`;
  const stars = SKILLS.map((k, i) => {
    const lv = lvOf(k.id);
    const owned = lv > 0;
    return `
      <button class="ostar ${owned ? 'owned' : 'locked'} ${k.id === sel.id ? 'sel' : ''} ${scrolls.includes(k.id) ? 'scrolled' : ''}"
        data-a="skillStar" data-id="${k.id}" style="left:${k.pos[0]}%;top:${((k.pos[1] * scaleY) / ORION_H) * 100}%;--sc:${k.color};--d:${i}">
        <span class="ostar-core">${shapeIcon(k.shape)}</span>
        ${owned ? '' : `<span class="ostar-lock">${icon('lock')}</span>`}
        <em>${t('skill.' + k.id + '.short')}</em>
      </button>`;
  }).join('');

  // parşömen kutuları
  let slots = '';
  for (let i = 0; i < SCROLL_SLOTS; i++) {
    const id = scrolls[i];
    const k = id ? SKILL_BY_ID.get(id) : undefined;
    slots += k
      ? `<button class="scroll-slot full" data-a="skillStar" data-id="${k.id}" style="--sc:${k.color}">${shapeIcon(k.shape)}<span>${t('shape.' + k.shape)}</span></button>`
      : `<div class="scroll-slot empty"><b>+</b><span>${t('skills.empty')}</span></div>`;
  }

  // seçili yıldızın ayrıntısı
  const lv = lvOf(sel.id);
  const owned = lv > 0;
  const cost = owned ? skillUpCost(sel, lv) : sel.price;
  const maxed = owned && cost < 0;
  const L = Math.max(1, lv);
  const stat = (l: number): string => `${t('skills.cd', { n: sel.cd[l - 1] })} · ${t('skill.' + sel.id + '.p', { v: dec(sel.power[l - 1]) })}`;
  let nodes = '';
  for (let n = 1; n <= SKILL_MAX_LV; n++) {
    if (n > 1) nodes += `<s class="${n <= lv ? 'on' : ''}"></s>`;
    nodes += `<i class="node ${n <= lv ? 'on' : ''} ${n === lv + 1 ? 'next' : ''}"><b>${n}</b></i>`;
  }
  const buy = maxed
    ? `<span class="buy done">${icon('crown')}${t('skills.max')}</span>`
    : `<button class="buy ${save.coins >= cost ? '' : 'disabled'}" data-a="buySkill" data-id="${sel.id}">${owned ? t('skills.upgrade') : t('skills.unlock')}<em>${icon('coin')}${fmt(cost)}</em></button>`;
  const inScroll = scrolls.includes(sel.id);
  const scrollBtn = owned
    ? `<button class="btn-scroll ${inScroll ? 'on' : ''}" data-a="scrollToggle" data-id="${sel.id}">${icon('scroll')}${inScroll ? t('skills.removeScroll') : t('skills.addScroll')}</button>`
    : '';
  const path = shapePath(sel.shape);
  const detail = `
    <div class="sdetail" style="--sc:${sel.color}">
      <div class="sd-top">
        <div class="sd-demo">
          <svg viewBox="-6 -6 112 112" aria-hidden="true">
            <path class="ghost" d="${path}"/>
            <path class="draw" d="${path}" pathLength="100"/>
          </svg>
          <span class="sd-shape">${t('skills.draw')} <b>${t('shape.' + sel.shape)}</b></span>
        </div>
        <div class="sd-info">
          <small>${sel.star}${inScroll ? ` · ${icon('scroll')}${t('skills.inScroll')}` : ''}</small>
          <h4>${icon(sel.icon)}<span>${t('skill.' + sel.id)}</span></h4>
          <p>${t('skill.' + sel.id + '.d')}</p>
          <div class="tree-track">${nodes}</div>
          <div class="tree-stat">${stat(L)}</div>
        </div>
      </div>
      <p class="sd-how">${t('skills.how', { shape: t('shape.' + sel.shape).toLocaleLowerCase(getLang() === 'tr' ? 'tr-TR' : 'en-US'), name: t('skill.' + sel.id) })}</p>
      <div class="sd-actions">${buy}${scrollBtn}</div>
    </div>`;

  const body = `
    <p class="lead">${t('skills.desc')}</p>
    <div class="orion"><div class="orion-box">${sky}${stars}</div></div>
    ${detail}
    <div class="scrolls-bar">
      <div class="scrolls-title">${icon('scroll')}<b>${t('skills.scrolls')}</b><span>${scrolls.length}/${SCROLL_SLOTS}</span></div>
      <div class="scroll-slots">${slots}</div>
      <p class="scroll-note">${t('skills.scrollNote')}</p>
    </div>`;
  return panel('skills', t('skills.title'), body, save.coins);
}

function upgradeDesc(id: string, nextLevel: number): string {
  const def = UPGRADE_BY_ID.get(id)!;
  const v = def.value ? def.value(nextLevel) : '';
  return t(`upg.${id}.d`, { v });
}

export function upgradeHTML(ids: string[], levels: Record<string, number>, sub: string, rerolls: number): string {
  const cards = ids
    .map((id, i) => {
      const def = UPGRADE_BY_ID.get(id)!;
      const lvl = levels[id] ?? 0;
      const tag = id === 'repair' ? '' : lvl === 0 ? t('up.new') : t('up.level', { n: lvl + 1 });
      return `
      <button class="card" data-a="pick" data-id="${id}" style="--d:${i}">
        <div class="card-icon">${icon(def.icon)}</div>
        <div class="card-body">
          ${tag ? `<span class="lvl">${tag}</span>` : ''}
          <h3>${t('upg.' + id)}</h3>
          <p>${upgradeDesc(id, lvl + 1)}</p>
        </div>
      </button>`;
    })
    .join('');
  return `
    <section class="screen upgrade" id="upgrade">
      <h2>${t('up.title')}</h2>
      <p class="sub">${sub}</p>
      <div class="cards">${cards}</div>
      ${rerolls > 0 ? `<div class="reroll-row"><button class="btn-ghost" data-a="reroll">${icon('reroll')}${t('up.reroll', { n: rerolls })}</button></div>` : ''}
    </section>`;
}

export function pauseHTML(save: SaveData): string {
  const st = save.settings;
  return `
    <section class="screen pause" id="pause">
      <div class="pause-box">
        <h2>${t('pause.title')}</h2>
        <button class="btn-play" data-a="resume">${icon('play')}${t('pause.resume')}</button>
        <div class="toggles">
          <button class="tog ${st.music ? 'on' : ''}" data-a="set" data-k="music">${icon('music')}${t('settings.music')}</button>
          <button class="tog ${st.sfx ? 'on' : ''}" data-a="set" data-k="sfx">${icon('sound')}${t('settings.sfx')}</button>
          <button class="tog ${st.haptics ? 'on' : ''}" data-a="set" data-k="haptics">${icon('vibrate')}${t('settings.haptics')}</button>
        </div>
        <button class="btn-ghost" data-a="restart">${icon('restart')}${t('pause.restart')}</button>
        <button class="btn-ghost" data-a="quit">${icon('home')}${t('pause.menu')}</button>
        <p class="note">${t('pause.note')}</p>
      </div>
    </section>`;
}

export function overHTML(r: RunResult, st: Settlement, best: number, dailyBest: number, canDouble = false, noAds = false): string {
  const p = rankProgress(best);
  const rankUp = st.rankAfter > st.rankBefore;
  const rows: string[] = [];
  let d = 0;
  rows.push(
    `<div class="reward-row gold" style="--d:${d++}"><span>${t('over.coins')}</span><span class="reward">${icon('coin')}<span id="o-coins">0</span></span></div>`,
  );
  if (st.streakBonus > 0) {
    rows.push(`<div class="reward-row" style="--d:${d++}"><span>${icon('flame')} ${t('over.streak', { n: Math.round(st.streakBonus / 25) })}</span><span class="reward">+${st.streakBonus}</span></div>`);
  }
  for (const m of st.missions) {
    rows.push(
      `<div class="reward-row gold" style="--d:${d++}"><span>${icon('check')} ${t('m.' + m.id, { n: fmt(m.target) })}</span><span class="reward">+${fmt(m.reward)}</span></div>`,
    );
  }
  if (r.daily) {
    rows.push(`<div class="reward-row" style="--d:${d++}"><span>${st.dailyBest ? t('over.dailyBest') : t('over.daily', { n: fmt(dailyBest) })}</span><span>${icon('calendar')}</span></div>`);
  }
  const toBest = !st.newBest && st.prevBest > 0 ? `<div class="tobest">${t('over.toBest', { n: fmt(st.prevBest - r.score) })}</div>` : '';
  return `
    <section class="screen over" id="over">
      <div class="over-scroll">
      <div class="over-inner">
      <div class="over-title">${t('over.title')}</div>
      ${(() => {
        const wi = atmosphereIndexForWave(Math.max(1, r.wave));
        const a = ATMOSPHERES[wi];
        return `<div class="world-chip" style="--ac:${a.accent}">${icon('planet')}${t('banner.chapter', { n: wi + 1 })} · ${t('atm.' + a.id)}</div>`;
      })()}
      <div class="over-score">
        <span class="label">${t('over.score')}</span>
        <b id="o-score">0</b>
        ${st.newBest && r.score > 0 ? `<div class="newbest">${t('over.newBest')}</div>` : toBest}
      </div>
      ${rankCard(p, best, rankUp ? 'levelup' : '', rankUp)}
      <div class="stats">
        <div><span class="label">${t('over.wave')}</span><b>${r.wave}</b></div>
        <div><span class="label">${t('over.combo')}</span><b>${r.maxCombo}</b></div>
        <div><span class="label">${t('over.kills')}</span><b>${r.kills}</b></div>
        <div><span class="label">${t('over.time')}</span><b>${fmtTime(r.time)}</b></div>
      </div>
      <div class="rewards">${rows.join('')}</div>
      </div>
      </div>
      <div class="over-foot">
      ${
        canDouble && st.coins > 0
          ? `<button class="btn-video double" data-a="double">${icon(noAds ? 'x2' : 'video')}<span>${t('over.double', { n: fmt(st.coins) })}</span></button>`
          : ''
      }
      <div class="over-actions">
        <button class="btn-play" data-a="again">${icon('restart')}${t('over.again')}</button>
        <button class="btn-ghost" data-a="menu" aria-label="${t('over.menu')}">${icon('home')}</button>
      </div>
      </div>
    </section>`;
}

/** menü başına vurgu rengi (başlık altı mürekkep çizgisi, vitrin) */
const PANEL_AC: Record<string, string> = {
  pens: '#3EF0E0',
  workshop: '#5CC8FF',
  missions: '#FF7A45',
  records: '#FFC857',
  shop: '#FFC857',
  settings: '#B57BFF',
  daily: '#FF7A45',
  worlds: '#3EF0E0',
  skills: '#B57BFF',
};

/**
 * Menü iskeleti: üst çubuk ana ekranla aynı (geri, başlık, altın pili); başlığın altında menünün
 * renginde kendini çizen bir mürekkep çizgisi. Sekmeler arası geçişte yalnızca içerik kayar.
 */
function panel(id: string, title: string, body: string, coins: number): string {
  return `
    <section class="screen panel" id="panel-${id}" style="--pac:${PANEL_AC[id] ?? 'var(--ink)'}">
      <div class="panel-head">
        <button class="icon-btn" data-a="close" aria-label="${t('common.back')}">${icon('back')}</button>
        <h2 class="${title.length > 14 ? 'long' : ''}"><span>${title}</span><svg class="head-stroke" viewBox="0 0 120 10" preserveAspectRatio="none" aria-hidden="true"><path d="M3 6 C 28 1, 52 9, 78 5 S 108 3, 117 6"/></svg></h2>
        <button class="currency" data-a="shop">${icon('coin')}<b class="coin-count">${fmt(coins)}</b><span class="plus">+</span></button>
      </div>
      <div class="panel-body">${body}</div>
    </section>`;
}

/**
 * Menü vitrini: derin uzay kartı, renkli bulutsu, göz kırpan yıldızlar; solda yörüngesinde uydu
 * dönen parlak bir gezegen (menü simgesi), altta kendini çizen bir mürekkep çizgisi.
 */
function hero(ic: string, title: string, sub: string, stat: string, statLabel: string, c1: string, c2: string): string {
  return `
    <div class="p-hero" style="--h1:${c1};--h2:${c2}">
      <i class="ph-neb"></i><i class="ph-stars"></i>
      <div class="ph-art">
        <svg class="ph-orbit" viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="46"/></svg>
        <i class="ph-moon"></i>
        <span class="ph-planet">${icon(ic)}</span>
      </div>
      <div class="ph-txt"><h3>${title}</h3><p>${sub}</p></div>
      ${stat ? `<div class="ph-stat"><b>${stat}</b><small>${statLabel}</small></div>` : ''}
      <svg class="ph-ink" viewBox="0 0 300 14" preserveAspectRatio="none" aria-hidden="true"><path d="M4 9 C 60 2, 118 13, 176 7 S 258 3, 296 8"/></svg>
    </div>`;
}

export function dailyHTML(save: SaveData, d: DailyInfo): string {
  const now = new Date();
  const end = new Date(now);
  end.setHours(24, 0, 0, 0);
  const mins = Math.max(0, Math.round((end.getTime() - now.getTime()) / 60000));
  const today = save.daily.date === d.key ? save.daily : { best: 0, attempts: 0 };
  const streakDays = Array.from({ length: 7 }, (_, i) => `<i class="${i < Math.min(save.streak.count, 7) ? 'on' : ''}"></i>`).join('');
  const body = `
    <p class="lead enter">${t('daily.desc')}</p>
    <div class="daily-hero enter" style="--d:1">
      <div class="mod">${t('mod.' + d.mod.id)}</div>
      <p>${t('mod.' + d.mod.id + '.d')}</p>
    </div>
    <div class="kv enter" style="--d:1">
      <div><span class="label">${t('daily.best')}</span><b>${fmt(today.best)}</b><small class="lead">${t('daily.attempts', { n: today.attempts })}</small></div>
      <div><span class="label">${t('daily.streak')}</span><b>${t('daily.streakDays', { n: save.streak.count })}</b><div class="streak-days">${streakDays}</div></div>
    </div>
    <p class="lead enter" style="--d:2">${t('daily.streakHint')} ${t('daily.coins')}.</p>
    <button class="btn-play gold enter" style="--d:3" data-a="playDaily">${icon('play')}${t('daily.play')}</button>
    <p class="note enter" style="--d:4">${t('daily.resets', { h: Math.floor(mins / 60), m: mins % 60 })}</p>`;
  return panel('daily', t('daily.title'), body, save.coins);
}

export function missionsHTML(save: SaveData): string {
  const colors: Record<string, string> = {
    kills: '#FF7A45',
    combo: '#FFC857',
    wave: '#3EF0E0',
    score: '#8B9CFF',
    perfect: '#3DF58A',
    boss: '#FF4D6D',
    golden: '#FFC857',
    oneline: '#5CC8FF',
    chain: '#B57BFF',
    deflects: '#3EF0E0',
    daily: '#FF9A3D',
  };
  const icons: Record<string, string> = {
    kills: 'blast',
    combo: 'bolt',
    wave: 'lines',
    score: 'star',
    perfect: 'check',
    boss: 'crown',
    golden: 'coin',
    oneline: 'nib',
    chain: 'bolt',
    deflects: 'bounce',
    daily: 'calendar',
  };
  let total = 0;
  const rows = save.missions
    .map((m, i) => {
      const frac = Math.min(1, m.progress / m.target);
      total += m.reward;
      return `
      <div class="row mission ${frac >= 1 ? 'done' : ''}" style="--d:${i + 1};--tc:${colors[m.id] ?? '#3EF0E0'}">
        <div class="ic">${icon(icons[m.id] ?? 'target')}</div>
        <div class="row-main">
          <h4>${t('m.' + m.id, { n: fmt(m.target) })}</h4>
          <div class="progress-mini"><i style="--w:${(frac * 100).toFixed(1)}%;--f:${frac.toFixed(3)}"></i></div>
          <p><b>${fmt(Math.min(m.progress, m.target))}</b> / ${fmt(m.target)}<span class="pct">%${Math.round(frac * 100)}</span></p>
        </div>
        <span class="reward">${icon('coin')}${fmt(m.reward)}</span>
      </div>`;
    })
    .join('');
  const head = hero('target', t('missions.hero'), t('missions.desc'), `${icon('coin')}${fmt(total)}`, t('hero.rewards'), '#FF7A45', '#FF4F8B');
  return panel('missions', t('missions.title'), `${head}<div class="list">${rows}</div>`, save.coins);
}

export function workshopHTML(save: SaveData): string {
  const colors = ['#3EF0E0', '#5CC8FF', '#B57BFF', '#FF6AA8', '#FFC857', '#FF9A3D', '#8B9CFF'];
  let lv = 0;
  let lvMax = 0;
  const rows = WORKSHOP.map((w, i) => {
    const lvl = save.workshop[w.id] ?? 0;
    lv += lvl;
    lvMax += w.max;
    const maxed = lvl >= w.max;
    const cost = maxed ? 0 : w.cost(lvl);
    const can = !maxed && save.coins >= cost;
    const dots = Array.from({ length: w.max }, (_, k) => `<i class="${k < lvl ? 'on' : ''}" style="--k:${k}"></i>`).join('');
    return `
      <div class="row ws ${maxed ? 'maxed' : ''}" style="--d:${i + 1};--tc:${colors[i % colors.length]}">
        <div class="ic">${icon(w.icon)}</div>
        <div class="row-main">
          <h4>${t('ws.' + w.id)}</h4>
          <p>${t('ws.' + w.id + '.d')}</p>
          <div class="lvl-line"><div class="lvl-dots">${dots}</div><small>${t('ws.lvl', { a: lvl, b: w.max })}</small></div>
        </div>
        ${
          maxed
            ? `<span class="buy done">${icon('crown')}${t('workshop.max')}</span>`
            : `<button class="buy ${can ? 'can' : 'disabled'}" data-a="buyWs" data-id="${w.id}">${icon('coin')}${fmt(cost)}</button>`
        }
      </div>`;
  }).join('');
  const head = hero('hammer', t('workshop.hero'), t('workshop.desc'), `${lv}/${lvMax}`, t('hero.levels'), '#5CC8FF', '#8B5CF6');
  return panel('workshop', t('workshop.title'), `${head}<div class="list">${rows}</div>`, save.coins);
}

function penSwatch(p: Pen, id: string): string {
  const stroke = p.rainbow ? `url(#rg-${id})` : p.color;
  const grad = p.rainbow
    ? `<defs><linearGradient id="rg-${id}" x1="0" x2="1"><stop offset="0" stop-color="#ff4f8b"/><stop offset=".25" stop-color="#ffc857"/><stop offset=".5" stop-color="#3df58a"/><stop offset=".75" stop-color="#3ef0e0"/><stop offset="1" stop-color="#a77bff"/></linearGradient></defs>`
    : '';
  return `<svg class="pen-swatch" viewBox="0 0 140 54">${grad}
    <path d="M10 38 C 40 6, 72 50, 130 16" stroke="${stroke}" stroke-width="16" opacity=".22"/>
    <path d="M10 38 C 40 6, 72 50, 130 16" stroke="${stroke}" stroke-width="7"/>
    <path d="M10 38 C 40 6, 72 50, 130 16" stroke="${p.core}" stroke-width="2.4"/></svg>`;
}

export function pensHTML(save: SaveData): string {
  const bestRank = rankProgress(save.best).idx;
  let owned = 0;
  const cards = PENS.map((p, i) => {
    const equipped = save.pen === p.id;
    const rankLocked = p.rank !== undefined && bestRank < p.rank;
    // ücretsiz kalem de rütbesi yetmiyorsa kilitli kalır
    const has = save.pens.includes(p.id) || (p.price === 0 && !rankLocked);
    if (has) owned++;
    let btn: string;
    if (equipped) btn = `<span class="buy done">${icon('check')}${t('pens.equipped')}</span>`;
    else if (has) btn = `<button class="buy ghost" data-a="equip" data-id="${p.id}">${t('pens.equip')}</button>`;
    else if (rankLocked) btn = `<span class="buy ghost disabled">${icon('lock')}${t('pens.needRank', { rank: rankLabel(p.rank!) })}</span>`;
    else btn = `<button class="buy ${save.coins >= p.price ? 'can' : 'disabled'}" data-a="buyPen" data-id="${p.id}">${icon('coin')}${fmt(p.price)}</button>`;
    return `
      <div class="pen ${equipped ? 'equipped' : ''} ${rankLocked && !has ? 'locked' : ''}" style="--pc:${p.rainbow ? '#B57BFF' : p.color};--d:${i + 1}">
        <div class="pen-well">${penSwatch(p, p.id)}${equipped ? `<span class="pen-badge">${icon('check')}</span>` : ''}</div>
        <h4>${t('pen.' + p.id)}</h4>
        ${btn}
      </div>`;
  }).join('');
  const head = hero('pen', t('pens.hero'), t('pens.desc'), `${owned}/${PENS.length}`, t('hero.owned'), '#3EF0E0', '#B57BFF');
  return panel('pens', t('pens.title'), `${head}<div class="pen-grid">${cards}</div>`, save.coins);
}

export function recordsHTML(save: SaveData): string {
  const recs = save.records.length
    ? save.records
        .map(
          (r, i) => `
      <div class="rec ${i < 3 ? 'podium p' + (i + 1) : ''}" style="--d:${i + 2}">
        <span class="pos">${i < 3 ? icon(i === 0 ? 'crown' : 'star') : ''}<em>${i + 1}</em></span>
        <div><b>${fmt(r.score)}</b><small>${t('over.wave')} ${r.wave} · ${r.date}${r.daily ? ' · ' + t('st.daily') : ''}</small></div>
        ${i === 0 ? `<span class="rec-best">${icon('trophy')}</span>` : '<span></span>'}
      </div>`,
        )
        .join('')
    : `<div class="empty-card">${icon('trophy')}<p>${t('records.empty')}</p></div>`;
  const stat = (ic: string, c: string, label: string, v: string, i: number): string =>
    `<div class="stat" style="--tc:${c};--d:${i}"><span class="st-ic">${icon(ic)}</span><span class="label">${label}</span><b>${v}</b></div>`;
  const stats = `
    <div class="kv stats">
      ${stat('play', '#3EF0E0', t('st.runs'), fmt(save.totalRuns), 3)}
      ${stat('blast', '#FF7A45', t('st.kills'), fmt(save.totalKills), 4)}
      ${stat('lines', '#5CC8FF', t('st.wave'), String(save.bestWave), 5)}
      ${stat('bolt', '#FFC857', t('st.combo'), String(save.bestCombo), 6)}
      ${stat('crown', '#FF4D6D', t('st.boss'), String(save.bossKills), 7)}
      ${stat('clock', '#B57BFF', t('st.time'), fmtDuration(save.totalPlaySec), 8)}
    </div>`;
  return panel(
    'records',
    t('records.title'),
    `${rankCard(rankProgress(save.best), save.best, 'enter')}<div class="section-title">${t('records.top')}</div><div class="list">${recs}</div><div class="section-title">${t('records.stats')}</div>${stats}`,
    save.coins,
  );
}

export function settingsHTML(save: SaveData, version: string, canFullscreen: boolean, resetArmed: boolean): string {
  const st = save.settings;
  const sw = (k: string, on: boolean, ic: string, label: string): string => `
    <button class="toggle-row" data-a="set" data-k="${k}"><span class="l">${icon(ic)}${label}</span><span class="switch ${on ? 'on' : ''}"></span></button>`;
  const seg = (k: string, opts: Array<[string, string]>, val: string): string =>
    `<div class="seg">${opts.map(([v, l]) => `<button class="${v === val ? 'on' : ''}" data-a="setv" data-k="${k}" data-v="${v}">${l}</button>`).join('')}</div>`;
  const body = `
    <div class="list">
      ${sw('music', st.music, 'music', t('settings.music'))}
      ${sw('sfx', st.sfx, 'sound', t('settings.sfx'))}
      ${sw('haptics', st.haptics, 'vibrate', t('settings.haptics'))}
      <div class="toggle-row"><span class="l">${icon('star')}${t('settings.quality')}</span>${seg(
        'quality',
        [
          ['high', t('q.high')],
          ['balanced', t('q.balanced')],
          ['saver', t('q.saver')],
        ],
        st.quality,
      )}</div>
      <div class="toggle-row"><span class="l">${icon('info')}${t('settings.lang')}</span>${seg(
        'lang',
        [
          ['auto', t('lang.auto')],
          ['tr', 'TR'],
          ['en', 'EN'],
        ],
        st.lang,
      )}</div>
      ${sw('showFps', st.showFps, 'chart', t('settings.fps'))}
      ${canFullscreen ? `<button class="toggle-row" data-a="fullscreen"><span class="l">${icon('expand')}${t('settings.fullscreen')}</span><span></span></button>` : ''}
    </div>
    <div class="section-title"></div>
    <div class="list">
      <button class="btn-ghost" data-a="tutorial">${icon('info')}${t('settings.tutorial')}</button>
      <button class="btn-ghost danger" data-a="reset">${icon('restart')}${resetArmed ? t('settings.resetConfirm') : t('settings.reset')}</button>
    </div>
    <p class="credits">${t('settings.credits', { v: version })}</p>`;
  return panel('settings', t('settings.title'), body, save.coins);
}

export function bannerHTML(big: string, small: string, boss: boolean, color?: string): string {
  return `
    <div class="banner ${boss ? 'boss' : ''}" ${color ? `style="--bc:${color}"` : ''}>
      <div class="big ${big.length > 10 ? 'long' : ''}">${big}</div>
      <svg class="stroke" viewBox="0 0 300 16" preserveAspectRatio="none"><path d="M6 10 C 70 2, 120 14, 170 8 S 260 4, 294 9"/></svg>
      ${small ? `<div class="small">${small}</div>` : ''}
    </div>`;
}

export function toastHTML(ic: string, text: string): string {
  return `<div class="toast">${icon(ic)}<span>${text}</span></div>`;
}

